<?php
define('TEMPLATES_DIR', '../templates/');
define('LAYOUTS_DIR', 'layouts/');
define('PATH', 'http://'.$_SERVER['HTTP_HOST'].'/');

/* DB config */
define('HOST', 'localhost:3306');
define('USER', 'geekb_php_1');
define('PASS', 'rhenjec74');
define('DB', 'geekb_php_1');

include "../engine/db.php";
include "../engine/functions.php";
include "../engine/log.php";
include "../engine/gallery.php";
include "../engine/catalog.php";
include "../engine/menu.php";
include "../engine/upload.php";