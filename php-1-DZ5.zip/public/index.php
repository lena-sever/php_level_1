<?php

//Первым делом подключим файл с константами настроек
include "../config/config.php";

$url_array = explode('/', $_SERVER['REQUEST_URI']);
// echo '<pre>';
// print_r($url_array);
// exit;

//Читаем параметр page из url, чтобы определить, какую страницу-шаблон
//хочет увидеть пользователь, по умолчанию это будет index
if ($url_array[1] == "") { 
    $page = 'index';
} else {
    $page = $url_array[1];
}


// Параметры
$params = [
    'count' => 2
];

$params['menu'] = menuRender($menu_array);

switch ($page) {
    case 'index':
        $params['name'] = 'Alex';
        break;

    case 'catalog':
        $params['catalog'] = getCatalog();
        break;

    case 'gallery':
        $params['message'] = getMessage();
        $params['gallery'] = getGallery();
        $num_foto = count($params['gallery']) + 1;
        if (!empty($_FILES)) {
            upload_foto($num_foto);
        }
        break;

    case 'img':
        $id = (int)$_GET['id'];
        $params['gal_img'] = getOneImg($id);
        add_view_img($id);
    break;
    
    case 'apicatalog':
        echo json_encode(getCatalog(), JSON_UNESCAPED_UNICODE);
        die();

    default:
        $page = 'index';
}

//_log($params, "render");
echo render($page, $params);
