<?php
function getGallery() {
    // $gallery = array_splice(scandir("images/gallery_img/big"), 2);
    $sql = "SELECT * FROM `gallery` ORDER BY likes DESC";
    $gallery = getAssocResult($sql);
    return $gallery;
}

function getOneImg($id) {
    return getAssocResult("SELECT * FROM gallery WHERE id = {$id}")[0];
}

// увеличение количества просмотров
function add_view_img($id) {
    $sql = "UPDATE `gallery` SET likes=likes+1 WHERE `id` = {$id}";
    return executeSql($sql);
}

// загрузка картинок
function getMessage(){
    if ($_GET['message']) {
        $key = $_GET['message'];
        $answer = [
            'ok' => 'Файл заружен',
            'error' => 'Ошибка загрузки',
            'error_size' => 'Размер файла не больше 3 мб',
            'error_type' => 'Допустимые расширения - .gif, .jpg, .png'
        ];
        return $answer[$key];
    }
}

function upload_foto($num_foto){

    $ext = strtolower(preg_replace("#.+\.([a-z]+)$#i", "$1", $_FILES['myfile']['name'])); // расширение картинки
    $new_name = $num_foto .'.'. $ext;
    $path = "images/gallery_img/big/" . $new_name;
    $size = $_FILES['myfile']['size'];

    //Проверить разрешено ли загружать такой файл
    //Проверка на размер файла
    if ($size > 1024 * 1024 * 3) {
        header("Location: /gallery/?message=error_size");
        exit;
    }
    //проверка на расширения
    $types = array("image/gif", "image/png", "image/jpeg", "image/pjpeg", "image/x-png"); 
    if(!in_array($_FILES['myfile']['type'], $types)){
        header("Location: /gallery/?message=error_type");
        exit;
    }

    if (move_uploaded_file($_FILES['myfile']['tmp_name'], $path)) {
        // запишем в БД
        $sql = "INSERT INTO `gallery` (`img`, `size`) VALUES ('{$new_name}', {$size})";
        executeSql($sql);

        // сделать ресайз файла $path, и сохранить его в small
        include_once("scripts/classSimpleImage.php");
        $image = new SimpleImage();
        $image->load("images/gallery_img/big/{$new_name}");
        $image->resize(150, 100);
        $image->save("images/gallery_img/small/{$new_name}");

        header("Location: /gallery/?message=ok");
        exit;
    } else {
        header("Location: /gallery/?message=error");
        exit;
    }
}