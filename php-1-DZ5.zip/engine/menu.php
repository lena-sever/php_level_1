<?php
$menu_array = [
	[
		"title" => "Главная",
		"href" => "/"
	],
	[
		"title" => "Каталог",
		"href" => "/catalog"
		/*, "subitems" => [
			[
				"title" => "Автомобили",
				"href" => "#"
			],
			[
				"title" => "Самолеты",
				"href" => "#",
				"subitems" => [
						[
							"title" => "Военные",
                            "href" => "#"
						],
						[
							"title" => "Гражданские",
                            "href" => "#"
                            ]
					]
			]
		]*/
	],
	[
		"title" => "Галерея",
		"href" => "/gallery"
	],
];

function menuRender($menu){
	$result = "";
    $result = "<ul class='menu'>";
	foreach($menu as $item){
		$result .= "<li><a href='{$item['href']}'>{$item['title']}</a>";
		
		if(isset($item["subitems"])){
			$result .= "<ul>";
			$result .= menuRender($item["subitems"]);
			$result .= "</ul>";
		}
		
		$result .= "</li>";
	}
    $result .= "</ul>";
	return $result;
}
