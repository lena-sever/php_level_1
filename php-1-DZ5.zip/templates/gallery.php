<h2>Галерея</h2>

<div id="main">
<div class="post_title"><h2>Моя галерея</h2></div>
	<div class="gallery">
        <?php foreach ($gallery as $item): ?>
        <a  href="/img/?id=<?=$item['id']?>"><img src="<?=PATH?>images/gallery_img/small/<?=$item['img']?>" width="150" height="100" /></a>
        <?php endforeach; ?>
    </div>
</div>

<form class="input_fotm" method="post" enctype="multipart/form-data">
        <input type="file" name="myfile">
        <input type="submit" value="Загрузить" name="load">
        <div class="mes"><?=$message?></div>
</form>

