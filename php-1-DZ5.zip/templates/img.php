<h1>Просмотр картинки</h1>
<img src="/images/gallery_img/big/<?=$gal_img['img']?>" alt="<?=$gal_img['img']?>">
<p>Размер изображения: <?=number_format($gal_img['size'] / 1024,0,'',' ') . ' KB'?></p>
<p>Просмотров: <?=$gal_img['likes']?></p>
<a href="/gallery">Назад в галлерею</a>