<?php
echo $menu;
?>
<a href="/basket">Корзина (<?=$count?>)</a>
<br>
